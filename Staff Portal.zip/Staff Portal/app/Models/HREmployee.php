<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HREmployee extends Model
{
    use HasFactory;
    public static function wsName(){
        return "QyEmployees";
    }
   /* {#815 ▼
  +"No": "ADMIN"
  +"FirstName": "Joseph"
  +"MiddleName": "Ndirangu"
  +"LastName": "Kariuki"
  +"FullName": "Joseph Ndirangu Kariuki"
  +"ResidentialAddress": ""
  +"City": ""
  +"PostCode": ""
  +"County": ""
  +"HomePhoneNumber": ""
  +"CellularPhoneNumber": ""
  +"WorkPhoneNumber": ""
  +"EMail": ""
  +"IDNumber": "309827620"
  +"Gender": " "
  +"Status": "Active"
  +"DepartmentCode": ""
  +"SupervisorNo": ""
  +"CompanyEMail": "ndirangujkariuki@gmail.com"
  +"Title": " "
  +"ContractType": ""
  +"ContractEndDate": "0001-01-01"
  +"Password": ""
  +"PortalPassword": ""
  +"ChangedPassword": false
  +"PortalResetToken": ""
  +"PortalResetTokenExpired": false
  +"UserID": ""
  +"Category": ""
  +"HODUserID": ""
  +"IsHOD": true
  +"HOD": false
  +"DateOfBirth": "0001-01-01"
  +"Age": ""
  +"JobID": "JOB0001"
  +"JobTitle": "Admin ICT"
  +"PortalOTPCode": ""
  +"PortalOTPDate": "0001-01-01"
  +"PortalOTPDevice": ""
  +"OTPCodeUsedToday": false
  +"PortalSessionToken": ""
  +"Picture@odata.mediaReadLink": "https://api.businesscentral.dynamics.com/v2.0/c472639a-a5ae-4142-a893-48bc62fe1eeb/sandbox/ODataV4/QyEmployees('ADMIN')/Picture?company='CRONUS%20International% ▶"
}*/
}
