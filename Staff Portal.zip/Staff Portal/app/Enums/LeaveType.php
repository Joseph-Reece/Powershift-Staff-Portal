<?php
enum LeaveType: string
{
    case ANNUAL = 'ANNUAL';
    case SICK = 'SICK';
    // Add other leave types
}