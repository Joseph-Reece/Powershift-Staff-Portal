<?php
    define('USERPWD', config('app.domainUser'));
?>
